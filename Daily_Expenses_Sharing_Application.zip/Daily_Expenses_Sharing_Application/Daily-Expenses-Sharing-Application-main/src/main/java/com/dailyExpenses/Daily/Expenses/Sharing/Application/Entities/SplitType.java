package com.dailyExpenses.Daily.Expenses.Sharing.Application.Entities;


public enum SplitType {

    EQUAL,

    EXACT,

    PERCENTAGE
}
