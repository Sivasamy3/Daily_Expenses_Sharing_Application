package com.dailyExpenses.Daily.Expenses.Sharing.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DailyExpensesSharingApplication {

    public static void main(String[] args) {
        SpringApplication.run(DailyExpensesSharingApplication.class, args);
        System.out.println("Entering the Application...");
    }
}
